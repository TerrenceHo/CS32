//
//  Sequence.cpp
//  Project2
//
//  Created by Kevin on 1/28/17.
//  Copyright © 2017 Kevin. All rights reserved.
//


#include "Sequence.h"
#include <iostream>

Sequence::Sequence() {
    m_size = 0;
    head = new Node;
    head->m_next = head;
    head->m_previous = head;
}
Sequence::~Sequence(){
    while(head->m_next != head){
        Node * p = head->m_previous;
        p->m_previous->m_next = head;
        head->m_previous = p->m_previous;
        delete p;
    }
    delete head;
}

Sequence::Sequence(const Sequence & obj){
    m_size = 0;
    head = new Node;
    head->m_next = head;
    head->m_previous = head;
    for(int i = 0; i < obj.size(); i++){
        ItemType temp;
        obj.get(i, temp);
        insert(i, temp);
    }
}

Sequence& Sequence::operator=(const Sequence& rhs)
{
    if(this!=&rhs)
    {
        Sequence temp(rhs);
        swap(temp);
    }
    return *this;
}

bool Sequence::empty() const{
    return m_size == 0;
}

int Sequence::size() const{
    return m_size;
}

bool Sequence::insert(int pos, const ItemType& value){
    if(pos > size() or pos < 0)
        return false;
    Node * temp = new Node;
    Node * p = head->m_next;
    for(int i = 0; i < pos; i++){//iterate until
        p = p->m_next;
    }
    temp->m_value = value;
    temp->m_next = p;
    temp->m_previous=p->m_previous;
    p->m_previous->m_next = temp;
    p->m_previous = temp;
    m_size++;
    return true;
}

int Sequence::insert(const ItemType& value) {
    Node* p = head->m_next;
    int count = 0;
    while(p!=head){//Increase it until value is less than the value at pointer p
        if(value <= p->m_value){
            break;
        }
        count++;
        p = p->m_next;
    }
    insert(count,value);
    return count;
}

bool Sequence:: erase(int pos){
    if(pos > size() or pos < 0)
        return false;
    Node * p = head->m_next;
    for(int i = 0; i<pos;i++){
        p=p->m_next;
    }
    p->m_previous->m_next = p->m_next;
    p->m_next->m_previous = p->m_previous;
    delete p;//delete p at very end
    m_size--;
    return true;
}

int Sequence:: remove(const ItemType& value){
    Node * p = head->m_next;
    int count = 0;
    while(p!= head){
        if(p->m_value == value){
            erase(count);
            return count;
        }
        p = p->m_next;
        count++;
    }
    return -1;
}

bool Sequence:: get(int pos, ItemType& value) const{
    if(pos < size() and pos >=0){
        Node * p = head->m_next;
        for(int i = 0; i < pos; i++){
            p = p->m_next;
        }
        value = p->m_value;
        return true;
    }
    return false;
}

bool Sequence:: set(int pos, const ItemType& value){
    if(pos < size() and pos >=0){
        Node * p = head->m_next;
        for(int i = 0; i < pos; i++){
            p = p->m_next;
        }
        p->m_value = value;
        return true;
    }
    return false;
}

int Sequence:: find(const ItemType& value) const{
    Node * p = head->m_next;
    int count = 0;
    while(p != head){
        if(p->m_value == value){
            return count;
        }
        p = p->m_next;
        count++;
    }
    return -1;
}

void Sequence:: swap(Sequence& other){
    Node * tempHead = other.head;
    other.head = head;
    head = tempHead;
    
    int tempSize = other.m_size;
    other.m_size = m_size;
    m_size = tempSize;
}

void Sequence::dump() const{
    Node * p = head->m_next;
    while(p != head){
        std::cout << p->m_value << ", ";
        p = p->m_next;
    }
    std::cout << std::endl;
}

int subsequence(const Sequence& seq1, const Sequence& seq2){
    if(seq1.size() < seq2.size() or seq2.empty()){
        return -1;
    }
    ItemType input1;
    ItemType input2;
    int startpoint;
    bool isASequence = false;
    for(int i = 0; i < seq1.size(); i++){
        seq1.get(i,input1);
        seq2.get(0,input2);
        if(input1 == input2){
            startpoint = i;
            for(int j = 0, startSequence = i; j < seq2.size(); j++, startSequence++){
                isASequence = true;
                seq1.get(startSequence, input1);
                seq2.get(j, input2);
                if(input1 != input2){
                    isASequence = false;
                    break;
                }
            }
            if(isASequence){
                return startpoint;
            }
        }
    }
    return -1;
}

void interleave(const Sequence& seq1, const Sequence& seq2, Sequence& result){
    int length;
    int count = 0;
    bool getCheck;
    ItemType temp;
    Sequence tempResult(result);
    while(!tempResult.empty())
        tempResult.erase(0);
    if(seq1.size() > seq2.size())
        length = seq1.size();
    else
        length = seq2.size();
    
    for(int i = 0; i < length; i++){
        getCheck = seq1.get(i,temp);
        if(getCheck){
            tempResult.insert(count,temp);
            count++;
        }
        getCheck = seq2.get(i,temp);
        if(getCheck){
            tempResult.insert(count, temp);
            count++;
        }
    }
    result = tempResult;
}

